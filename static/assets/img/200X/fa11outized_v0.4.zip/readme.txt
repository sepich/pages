Falloutized [MDMA edition] v0.4
././././././././././././././././.
v0.4 changes:
- skinned all windows!
- somewhere improved contrast
- some winshade effect in small windows.
 May be it not so cool, but i wanna skin, that will stay on my desktop for long without making tired of using it. One have light controls over dark background. So it no need to spend much time to find a button. I make buttons as large as possible. And it looks well together with my wallpapers and WinXP themes =) 
 What you see in this version was created under influence of FALLOUT (ruleZ!) and music of SPb Nu-Metall band "MDMA", so this is fan-art as i think=)
 Greetings:
deviantart.com & mdma.spb.ru (impress me of doing that)
You (download and read so much text =)
(sorry my bad english)
   Enjoy!
sepich@rambler.ru
sep.deviantart.com
Sep.         29mar04
